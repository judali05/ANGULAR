import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,MenuComponent,FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'app05';

  documento: number = 0;
  nombre_usuario: string = '';
  apellido_usuario: string = '';
  correo: string = '';


  enviar(){

    this.documento = 0;
    this.nombre_usuario = '';
    this.apellido_usuario = '';
    this.correo = '';
  
  }
   

}
