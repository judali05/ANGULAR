import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contacto',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './contacto.component.html',
  styleUrl: './contacto.component.css'
})
export class ContactoComponent {
  documento: number = 0;
  nombre_usuario: string = '';
  apellido_usuario: string = '';
 
  usuarios: any[] = [];

  enviar(){
    const usuario = {
      documento: this.documento,
      nombre_usuario: this.nombre_usuario,
      apellido_usuario: this.apellido_usuario,
    }
    
    this.usuarios.push(usuario);
    
    this.documento = 0;
    this.nombre_usuario = '';
    this.apellido_usuario = '';

  }
}