var mysql = require('mysql');
var express = require('express');
var app = express();

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "ubicacion"
});

app.use(express.json());

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200'); 
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
  });

app.get('/ciudades', (req, res) => {
    const query = 'SELECT * FROM productos'
    con.query(query, (error, resultado)=> {
        if(error) return console.error(error.message);

        if(resultado.length > 0){
            res.json(resultado);
        }else{
            res.json('No hay registros');
        }

    });
});

app.post('/ciudades/insertar', (req, res) => {
    const { codigo, descripcion, valor} = req.body;
    con.query("INSERT INTO productos ( codigo, descripcion, valor ) VALUES (?, ?, ?)",
        [codigo, descripcion, valor],
        (error, resultado) => {
            if (error) {
                return console.error(error.message);
            }
            res.json(resultado);

            //res.json({ "Item Añadido Correctamente": resultado.affectedRows });
        });
});

app.listen(8080, function(){
    console.log("Servidor Activo!");
});