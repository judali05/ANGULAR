import { TestBed } from '@angular/core/testing';

import { CiudadadesService } from './ciudadades.service';

describe('CiudadadesService', () => {
  let service: CiudadadesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CiudadadesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
