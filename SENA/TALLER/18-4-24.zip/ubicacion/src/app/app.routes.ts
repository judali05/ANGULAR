import { Routes } from '@angular/router';
import { InsertComponent } from './insert/insert.component';

export const routes: Routes = [
    {path:'insert', component: InsertComponent},
];
