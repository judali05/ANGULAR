import { Component } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CiudadadesService } from '../ciudadades.service';


@Component({
  selector: 'app-insert',
  standalone: true,
  imports: [FormsModule,RouterLink, CommonModule, ReactiveFormsModule],
  templateUrl: './insert.component.html',
  styleUrl: './insert.component.css'
})
export class InsertComponent {

  ciudades:any = {};

  constructor(private fb: FormBuilder, private ciudadadesService: CiudadadesService, private aRouter: ActivatedRoute) {}

  form = this.fb.group({
    codigo_c: [null, Validators.required],
    nombre: ['', Validators.required],
    codigo_d: [null, Validators.required]
  });

  alta(){

    const ciudades: any = {
      codigo_c: this.form.value.codigo_c,
      nombre: this.form.value.nombre,
      codigo_d: this.form.value.codigo_d
    }

  
    this.ciudadadesService.alta(ciudades).subscribe(() => {
        alert("Los datos se enviaron satisfactoriamente");
        this.form.reset({
          codigo_c: null,
          nombre: '',
          codigo_d: null
        });   
    })
  }

}

